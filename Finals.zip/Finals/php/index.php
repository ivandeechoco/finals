<?php

if(isset($_POST['submit'])):
    include_once 'db.inc';
    $stmt = $dbh->prepare("INSERT INTO student (fullname, studid,email,honor) VALUES (:fullname, :studid, :email, :honor)");
    $stmt->bindParam(':fullname', $_POST['fullname']);
    $stmt->bindParam(':studid', $_POST['studid']);
    $stmt->bindParam(':email', $_POST['email']);
    $stmt->bindParam(':honor', $_POST['honor']);
    $stmt->execute();
    try {
        $email = $_POST['email'];
        $fullname = $_POST['fullname'];

        $body = "test";
        $to = "awtzez@gmail.com"; // <– replace with your address here
        $subject = "testing";
        $message = $body;
        $from = "test@gmail.com";/*
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";*/
        $headers .= "From:" . $from;
        mail($to,$subject,$message,$headers);
       /* if(mail($to,$subject,$message,$headers))
        {
            echo json_encode(array('error' => 'success'));die();
//            echo json_encode($data);
        }
        else
        {
            echo json_encode(array('error' => '1'));die();
        }*/
    } catch (Exception $e) {
        echo $e->getMessage();die();
    }

    header('Location: view.php');
endif;
?>
<html>
<head>
    <title> Application Form </title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="login">
        <img src="https://online.apc.edu.ph/flavio/inquiry/images/apclogo.png" class="login_logo">
        <h2 class="title"> Application for Latin Awards</h2>
        <p class="subtitle"> Summa Cum Laude, Magna Cum Laude, Cum Laude</p>
        <hr/>


        <form method="post" action="index.php">
            <input type='text' name='fullname' value='' id="fullname" placeholder="Full Name" class="form_input" required>
            <input type='text' name='studid' value='' id="studid" placeholder="Student Id" class="form_input" required>
            <input type='email' name='email' value='' id="email" placeholder="Email" class="form_input" required>
            <select class="form_input" name="honor">
                <option value="summa cum laude">Summa Cum Laude</option>
                <option value="magna cum laude">Magna Cum Laude</option>
                <option value="cum laude">Cum Laude</option>
            </select>
            <button type="submit" name="submit" class="btn-primary">Submit</button>
            <small>For School Year 2018-2019</small>
        </form>
    </div>

</body>
</html>

