-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2019 at 08:36 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cldadmi_finals`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `studid` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `honor` varchar(255) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `fullname`, `studid`, `email`, `honor`, `created_date`) VALUES
(1, 'test', 'test', 'test@gmail.com', 'magna cum laude', '2019-04-13 16:17:43'),
(2, 'Archere Soliven Dimaculangan', 'test', 'asdf@gmail.com', 'magna cum laude', '2019-04-13 16:18:30'),
(3, 'testing', '2013-12345', 'testing@gmail.com', 'summa cum laude', '2019-04-13 16:47:10'),
(4, 'testing123', '2013-12345', 'testing@gmail.com', 'cum laude', '2019-04-13 16:47:20'),
(5, 'Archere Soliven Dimaculangan', 'asdf', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 17:31:30'),
(6, 'Archere Soliven Dimaculangan', 'asdf', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 17:31:41'),
(7, 'Archere Soliven Dimaculangan', 'asdf', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 17:39:51'),
(8, 'Archere Soliven Dimaculangan', 'asdf', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 17:39:53'),
(9, 'asd', 'asd', 'asdf@gmail.com', 'summa cum laude', '2019-04-13 17:44:46'),
(10, 'asd', 'asd', 'asdf@gmail.com', 'summa cum laude', '2019-04-13 17:45:05'),
(11, 'asd', 'asd', 'asdf@gmail.com', 'summa cum laude', '2019-04-13 17:45:19'),
(12, 'asd', 'asd', 'asdf@gmail.com', 'summa cum laude', '2019-04-13 17:47:35'),
(13, 'Archere Soliven Dimaculangan', 'test', 'awtzez@gmail.com', 'summa cum laude', '2019-04-13 17:50:13'),
(14, 'Archere Soliven Dimaculangan', 'test', 'awtzez@gmail.com', 'summa cum laude', '2019-04-13 17:55:14'),
(15, 'Archere Soliven Dimaculangan', 'test', 'awtzez@gmail.com', 'summa cum laude', '2019-04-13 17:56:32'),
(16, 'Archere Soliven Dimaculangan', 'test', 'awtzez@gmail.com', 'summa cum laude', '2019-04-13 17:58:09'),
(17, 'Archere Soliven Dimaculangan', 'test', 'awtzez@gmail.com', 'summa cum laude', '2019-04-13 17:59:53'),
(18, 'Archere Soliven Dimaculangan', 'test', 'awtzez@gmail.com', 'summa cum laude', '2019-04-13 18:02:41'),
(19, 'Archere Soliven Dimaculangan', 'asd', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:05:29'),
(20, 'asdfasdg', 'asdfgasdg', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:19:52'),
(21, 'asdfasdg', 'asdfgasdg', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:20:17'),
(22, 'asdfasdg', 'asdfgasdg', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:21:49'),
(23, 'Archere Soliven Dimaculangan', 'asdf', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:24:03'),
(24, 'Archere Soliven Dimaculangan', 'asdf', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:31:10'),
(25, 'Archere Soliven Dimaculangan', 'asdf', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:31:22'),
(26, 'Archere Soliven Dimaculangan', 'asdf', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:31:23'),
(27, 'Archere Soliven Dimaculangan', 'asdf', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:31:24'),
(28, 'Archere Soliven Dimaculangan', 'qwer', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:31:31'),
(29, 'Archere Soliven Dimaculangan', 'qwer', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:35:28'),
(30, 'Archere Soliven Dimaculangan', 'asdfgasdg', 'archeresoliven@gmail.com', 'summa cum laude', '2019-04-13 18:35:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
